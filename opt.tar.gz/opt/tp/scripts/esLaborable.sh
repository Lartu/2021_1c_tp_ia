#!/bin/bash

# Script que permite ingresar una fecha y te devuelve si es dia laborable en Argentina.
# Modo de uso: esLaborable.sh <dia><mes><year>
# Salida: 0 --> es laborable,  1 --> caso contrario

DAY=${1}
MONTH=${2}
YEAR=${3}

#gcal -q AR -N --> Obtengo todos los Feriados Nacionales

function esLaborable(){

	DAY=$1
	MONTH=$2
	YEAR=$3

	monthStr="`date -d "$YEAR-$MONTH-$DAY" +%b`" #obtengo el disminutivo del mes
	DOW="`date -d "$YEAR-$MONTH-$DAY" +%u`" #obteno el numero del dia de semaa 1-7

 	feriadoNacional="`cat /opt/tp/scripts/feriados.txt | grep "$DAY:$monthStr" `"

	if [ -z "$feriadoNacional" ]; then

		if [ $DOW -ne 6 ] && [ $DOW -ne 7 ]; then
			echo "es dia laborable"
			return 0
		else
			echo "es fin de semana"
			return 1
		fi
	else
		echo "Es Feriado Nacional:"
		echo "$feriadoNacional"
		return 1
	fi

}

esLaborable $DAY $MONTH $YEAR
