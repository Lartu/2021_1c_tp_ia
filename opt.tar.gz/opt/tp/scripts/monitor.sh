#!/bin/bash

# Script que si recibe un comando devuelve el estado del servicio y sino, 
# verifica si los servicios sshd, apache2, mysqld. 

servicios="`cat /opt/tp/scripts/services.txt`"

service=$1

if [ ! -z "$service" ]; then
	
		if `pgrep "$service" >/dev/null`
		then
			echo "$service se esta ejecutando"
		else
			echo "$service no se esta ejecutando"
		fi
else
	for servicio in $servicios; do

		if `pgrep "$servicio" >/dev/null`
		then
			echo "$servicio se esta ejecutando" > /dev/null
		else
			msg="$servicio no se esta ejecutando"
		        #echo $msg
			echo "$msg" | mail -s "$msg" root
			
			
		fi
	done
fi
